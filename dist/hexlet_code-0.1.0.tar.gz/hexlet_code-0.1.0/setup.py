# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formaters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/M1RRoN/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/M1RRoN/python-project-50/actions)\n[![CI check](https://github.com/M1RRoN/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/M1RRoN/python-project-50/actions/workflows/main.yml)\n[![Maintainability](https://api.codeclimate.com/v1/badges/d2f4d9e4f85b93802db9/maintainability)](https://codeclimate.com/github/M1RRoN/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/d2f4d9e4f85b93802db9/test_coverage)](https://codeclimate.com/github/M1RRoN/python-project-50/test_coverage)\n\n# DESCRIPTION:\n\n**Вычислитель отличий**\n\nЗапускается из командной строки и вычисляет отличия между двумя файлами. На данный момент работает с JSON и YAML.\n\n**Запуск справки:**\n\n`gendiff -h`\n\n**Запуск скрипта c настройками по-умолчанию:**\n\n`gendiff <file_path1> <file_path2>`\n\n**Сравнение двух плоских файлов: JSON.**\n\n[![asciicast](https://asciinema.org/a/3zhWyxxhT1EtmCFJsu5xe99Wv.svg)](https://asciinema.org/a/3zhWyxxhT1EtmCFJsu5xe99Wv)\n\n**Сравнение двух плоских файлов: YAML(YML).**\n\n[![asciicast](https://asciinema.org/a/Kk8dtomDr4D0pj1JZFvexlC6q.svg)](https://asciinema.org/a/Kk8dtomDr4D0pj1JZFvexlC6q)\n\n**Сравнение двух файлов c рекурсивной структурой: YAML(YML) или JSON.**\n\n[![asciicast](https://asciinema.org/a/Z3Kmjq3CtGRciJGYEv0xGgVN5.svg)](https://asciinema.org/a/Z3Kmjq3CtGRciJGYEv0xGgVN5)\n\nПлоский формат отображения - cравнение двух файлов c рекурсивной структурой YAML(YML) или JSON.\n\n[![asciicast](https://asciinema.org/a/lnEeDo5bboPNiL0JCViEWZlOO.svg)](https://asciinema.org/a/lnEeDo5bboPNiL0JCViEWZlOO)\n\nВывод результата сравнения в формате JSON.\n\n[![asciicast](https://asciinema.org/a/323hjECF1E2maaJY8K0DwaCok.svg)](https://asciinema.org/a/323hjECF1E2maaJY8K0DwaCok)\n',
    'author': 'Makeev095',
    'author_email': 'makeev095095@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
