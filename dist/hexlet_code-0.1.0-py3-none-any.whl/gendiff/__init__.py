from gendiff.diff_with_formatter import generate_diff

__all__ = (
    'generate_diff',
)
